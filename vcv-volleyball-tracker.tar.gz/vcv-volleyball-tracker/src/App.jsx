import React, { useState, useEffect } from 'react';
import { Menu, X, Users, Grid, RefreshCw, AlertTriangle, TrendingUp } from 'lucide-react';

export default function VolleyballTracker() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('game');
  const [players, setPlayers] = useState([
    { id: 1, name: 'Speler 1', number: 1, role: 'setter' },
    { id: 2, name: 'Speler 2', number: 2, role: 'outside' },
    { id: 3, name: 'Speler 3', number: 3, role: 'middle' },
    { id: 4, name: 'Speler 4', number: 4, role: 'opposite' },
    { id: 5, name: 'Speler 5', number: 5, role: 'outside' },
    { id: 6, name: 'Speler 6', number: 6, role: 'middle' },
    { id: 7, name: 'Libero', number: 7, role: 'libero', isLibero: true }
  ]);
  const [homeLineup, setHomeLineup] = useState({ 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, libero: 7 });
  const [awayLineup, setAwayLineup] = useState({ 1: 101, 2: 102, 3: 103, 4: 104, 5: 105, 6: 106 });
  const [startingHomeLineup, setStartingHomeLineup] = useState({ 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, libero: 7 });
  const [startingAwayLineup, setStartingAwayLineup] = useState({ 1: 101, 2: 102, 3: 103, 4: 104, 5: 105, 6: 106 });
  const [homeScore, setHomeScore] = useState(0);
  const [awayScore, setAwayScore] = useState(0);
  const [sets, setSets] = useState({ home: 0, away: 0 });
  const [homeTimeouts, setHomeTimeouts] = useState([]);
  const [awayTimeouts, setAwayTimeouts] = useState([]);
  const [servingTeam, setServingTeam] = useState('home');
  const [scoreHistory, setScoreHistory] = useState([]);
  const [heatmapData, setHeatmapData] = useState([]);
  const [setEnded, setSetEnded] = useState(false);
  const [matchEnded, setMatchEnded] = useState(false);
  const [setWinner, setSetWinner] = useState(null);
  const [matchWinner, setMatchWinner] = useState(null);
  const [showLineupConfirm, setShowLineupConfirm] = useState(false);
  const [confetti, setConfetti] = useState([]);
  const [substitutionMode, setSubstitutionMode] = useState(false);
  const [selectedBenchPlayer, setSelectedBenchPlayer] = useState(null);
  const [substitutions, setSubstitutions] = useState([]);
  const [subError, setSubError] = useState(null);
  const [sidebarExpanded, setSidebarExpanded] = useState(false);
  const [savedHeatmaps, setSavedHeatmaps] = useState([]);
  const [showHeatmapOverlay, setShowHeatmapOverlay] = useState(null);
  const [showPointTypePopup, setShowPointTypePopup] = useState(null);
  const [pointStats, setPointStats] = useState({
    home: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 },
    away: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 }
  });
  const [serviceFaultStats, setServiceFaultStats] = useState({
    home: [],
    away: []
  });
  const [showServiceFaultPopup, setShowServiceFaultPopup] = useState(null);
  const [opponentName, setOpponentName] = useState('');
  const [matchDate, setMatchDate] = useState(new Date().toISOString().split('T')[0]);
  const [alertMessage, setAlertMessage] = useState(null);
  const [showServingTeamDialog, setShowServingTeamDialog] = useState(false);
  const [pulsingPlayer, setPulsingPlayer] = useState(null);
  const [playSystem, setPlaySystem] = useState('5-1');
  const [showPenetration, setShowPenetration] = useState(true);
  const [inServicePosition, setInServicePosition] = useState(true); // Service vs Rally positie
  const [liberoSubHistory, setLiberoSubHistory] = useState([]); // Track libero wissels
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [ruleViolations, setRuleViolations] = useState([]);
  const [showNewMatchDialog, setShowNewMatchDialog] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showLoadDialog, setShowLoadDialog] = useState(false);
  const [savedMatches, setSavedMatches] = useState([]);
  const [showConfirmSaveBeforeNew, setShowConfirmSaveBeforeNew] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);
  const [windowWidth, setWindowWidth] = useState(1024); // Default desktop
  const [sidebarWidth, setSidebarWidth] = useState(320);
  const [isResizing, setIsResizing] = useState(false);
  const [compactSidebarWidth, setCompactSidebarWidth] = useState(280);
  const [isResizingCompact, setIsResizingCompact] = useState(false);
  const [selectedAnalysisSet, setSelectedAnalysisSet] = useState('current'); // 'current' of set nummer of 'overall'

  // Detect window width
  useEffect(() => {
    const updateWidth = () => {
      setWindowWidth(window.innerWidth);
      // Auto-adjust sidebars on mobile
      if (window.innerWidth < 640) {
        setSidebarWidth(window.innerWidth * 0.85);
        setCompactSidebarWidth(window.innerWidth * 0.10); // 10% op mobiel
      } else if (window.innerWidth < 1024) {
        setCompactSidebarWidth(Math.min(150, window.innerWidth * 0.15));
      }
    };
    
    updateWidth(); // Initial
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('volleyballMatches');
    if (saved) {
      setSavedMatches(JSON.parse(saved));
    }
    const savedWidth = localStorage.getItem('sidebarWidth');
    if (savedWidth) {
      setSidebarWidth(parseInt(savedWidth));
    }
    const savedCompactWidth = localStorage.getItem('compactSidebarWidth');
    if (savedCompactWidth) {
      setCompactSidebarWidth(parseInt(savedCompactWidth));
    }
  }, []);

  useEffect(() => {
    if (!isResizing) return;
    
    const handleMove = (e) => {
      const clientX = e.clientX || (e.touches && e.touches[0].clientX);
      if (!clientX) return;
      
      const newWidth = window.innerWidth - clientX;
      if (newWidth >= 280 && newWidth <= 600) {
        setSidebarWidth(newWidth);
        localStorage.setItem('sidebarWidth', newWidth.toString());
      }
    };
    
    const handleEnd = () => {
      setIsResizing(false);
    };
    
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);
    document.addEventListener('touchmove', handleMove);
    document.addEventListener('touchend', handleEnd);
    
    return () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleMove);
      document.removeEventListener('touchend', handleEnd);
    };
  }, [isResizing]);

  useEffect(() => {
    if (!isResizingCompact) return;
    
    const handleMove = (e) => {
      e.preventDefault(); // Voorkom scrolling tijdens resize
      const clientX = e.clientX || (e.touches && e.touches[0].clientX);
      if (!clientX) return;
      
      const newWidth = window.innerWidth - clientX;
      const minWidth = windowWidth < 640 ? windowWidth * 0.08 : 64; // Min 8% op mobiel
      const maxWidth = windowWidth < 640 ? windowWidth * 0.30 : 400; // Max 30% op mobiel
      
      if (newWidth >= minWidth && newWidth <= maxWidth) {
        setCompactSidebarWidth(newWidth);
      }
    };
    
    const handleEnd = () => {
      setIsResizingCompact(false);
      // Save to localStorage only after resize completes
      localStorage.setItem('compactSidebarWidth', compactSidebarWidth.toString());
    };
    
    document.addEventListener('mousemove', handleMove, { passive: false });
    document.addEventListener('mouseup', handleEnd);
    document.addEventListener('touchmove', handleMove, { passive: false });
    document.addEventListener('touchend', handleEnd);
    
    return () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleMove);
      document.removeEventListener('touchend', handleEnd);
    };
  }, [isResizingCompact, windowWidth, compactSidebarWidth]);

  useEffect(() => {
    if (setWinner === 'home' || matchWinner === 'home') {
      setConfetti(Array.from({ length: 50 }, (_, i) => ({ id: i, left: Math.random() * 100, delay: Math.random() * 2 })));
      setTimeout(() => setConfetti([]), 4000);
    }
  }, [setWinner, matchWinner]);

  // NeVoBo Libero Regels Validatie
  const validateLiberoSubstitution = (liberoId, playerOutId, currentLineup) => {
    const playerOut = players.find(p => p.id === playerOutId);
    
    // Regel 1: Libero mag alleen wisselen met achterlijn spelers (NOOIT positie 1 = serveren!)
    const playerPos = Object.entries(currentLineup).find(([, id]) => id === playerOutId)?.[0];
    if (playerPos && !['5', '6'].includes(playerPos)) {
      return { valid: false, reason: 'Libero mag alleen wisselen met achterlijn spelers op pos 5 en 6 (NIET pos 1 = serveren verboden!)' };
    }
    
    // Regel 2: Libero mag niet wisselen met een andere libero
    if (playerOut?.isLibero) {
      return { valid: false, reason: 'Libero mag niet wisselen met een andere libero' };
    }
    
    // Regel 3: Libero mag alleen terugwisselen met dezelfde speler
    const lastLiberoSub = liberoSubHistory[liberoSubHistory.length - 1];
    if (lastLiberoSub && lastLiberoSub.liberoId === liberoId && lastLiberoSub.type === 'in') {
      if (lastLiberoSub.playerOut !== playerOutId) {
        return { valid: false, reason: 'Libero mag alleen terugwisselen met dezelfde speler' };
      }
    }
    
    // Regel 4: Bij automatische libero wissels (midden naar achterlijn pos 5/6)
    // Controleer of dit een midden is
    if (playerOut?.role === 'middle') {
      return { valid: true, automatic: true };
    }
    
    return { valid: true };
  };

  // NeVoBo Wissel Regels Validatie  
  const validateSubstitution = (playerInId, playerOutId) => {
    // Regel 1: Maximum 6 wissels per set (NeVoBo)
    if (substitutions.length >= 6) {
      return { valid: false, reason: 'Maximum 6 wissels per set bereikt (NeVoBo regel)' };
    }
    
    // Regel 2: Speler mag alleen terugwisselen met dezelfde partner
    const existingSub = substitutions.find(s =>
      (s.playerOut === playerOutId && s.playerIn !== playerInId) ||
      (s.playerIn === playerOutId && s.playerOut !== playerInId)
    );
    
    if (existingSub) {
      const partner = existingSub.playerOut === playerOutId ? existingSub.playerIn : existingSub.playerOut;
      const partnerName = players.find(p => p.id === partner)?.name;
      return { valid: false, reason: `Mag alleen terug met ${partnerName} (NeVoBo regel)` };
    }
    
    // Regel 3: Libero wissels tellen niet mee voor de 6 wissels
    const playerIn = players.find(p => p.id === playerInId);
    const playerOut = players.find(p => p.id === playerOutId);
    
    if (playerIn?.isLibero || playerOut?.isLibero) {
      return validateLiberoSubstitution(playerInId, playerOutId, homeLineup);
    }
    
    return { valid: true };
  };

  const addPlayer = () => {
    const newId = Math.max(...players.map(p => p.id), 0) + 1;
    setPlayers([...players, { id: newId, name: `Speler ${newId}`, number: newId, role: 'outside' }]);
  };

  const updatePlayer = (id, field, value) => {
    setPlayers(players.map(p => {
      if (p.id === id) {
        const updated = { ...p, [field]: value };
        if (field === 'isLibero' && value === true) {
          updated.role = 'libero';
        }
        if (field === 'isLibero' && value === false && p.role === 'libero') {
          updated.role = 'outside';
        }
        return updated;
      }
      return p;
    }));
  };

  const removePlayer = (id) => {
    setPlayers(players.filter(p => p.id !== id));
  };

  const updateLineup = (team, pos, val) => {
    if (team === 'home') {
      setHomeLineup({ ...homeLineup, [pos]: val });
    } else {
      setAwayLineup({ ...awayLineup, [pos]: val });
    }
  };

  const confirmLineup = () => {
    setStartingHomeLineup(homeLineup);
    setStartingAwayLineup(awayLineup);
    setMenuOpen(false);
    
    if (sets.home === 0 && sets.away === 0 && homeScore === 0 && awayScore === 0) {
      setShowServingTeamDialog(true);
    }
  };

  const setInitialServingTeam = (team) => {
    setServingTeam(team);
    setShowServingTeamDialog(false);
    setInServicePosition(true); // Start in service positie
  };

  const confirmNewMatch = () => {
    if (!opponentName.trim()) {
      setAlertMessage('⚠️ Vul een tegenstander naam in');
      setTimeout(() => setAlertMessage(null), 2000);
      return;
    }

    setHomeScore(0);
    setAwayScore(0);
    setSets({ home: 0, away: 0 });
    setHomeTimeouts([]);
    setAwayTimeouts([]);
    setScoreHistory([]);
    setHeatmapData([]);
    setSavedHeatmaps([]);
    setSubstitutions([]);
    setLiberoSubHistory([]);
    setSetEnded(false);
    setMatchEnded(false);
    setSetWinner(null);
    setMatchWinner(null);
    setPointStats({
      home: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 },
      away: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 }
    });
    setServiceFaultStats({ home: [], away: [] });
    setShowNewMatchDialog(false);
    setShowServingTeamDialog(true);
  };

  const saveMatch = () => {
    if (!opponentName.trim()) {
      setAlertMessage('⚠️ Vul een tegenstander naam in om op te slaan');
      setTimeout(() => setAlertMessage(null), 2000);
      return;
    }

    const matchData = {
      id: Date.now(),
      opponent: opponentName,
      date: matchDate,
      finalScore: sets,
      winner: matchWinner,
      savedHeatmaps,
      substitutions,
      pointStats,
      scoreHistory,
      serviceFaultStats
    };

    const updated = [...savedMatches, matchData];
    setSavedMatches(updated);
    localStorage.setItem('volleyballMatches', JSON.stringify(updated));
    
    setShowSaveDialog(false);
    setAlertMessage('✅ Wedstrijd opgeslagen!');
    setTimeout(() => setAlertMessage(null), 2000);
  };

  const skipSave = () => {
    setShowSaveDialog(false);
    setShowNewMatchDialog(true);
  };

  const loadMatch = (match) => {
    setOpponentName(match.opponent);
    setMatchDate(match.date);
    setSets(match.finalScore);
    setMatchWinner(match.winner);
    setSavedHeatmaps(match.savedHeatmaps || []);
    setSubstitutions(match.substitutions || []);
    setPointStats(match.pointStats || {
      home: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 },
      away: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 }
    });
    setScoreHistory(match.scoreHistory || []);
    // NIET matchEnded op true zetten - review mode zonder popup
    setShowLoadDialog(false);
    setMenuOpen(true);
    setActiveTab('wedstrijden');
    setAlertMessage('✅ Wedstrijd geladen!');
    setTimeout(() => setAlertMessage(null), 2000);
  };

  const deleteMatch = (id) => {
    setShowDeleteConfirm(id);
  };

  const confirmStartNewWithSave = () => {
    saveMatch();
    setShowConfirmSaveBeforeNew(false);
    setShowNewMatchDialog(true);
  };

  const confirmStartNewWithoutSave = () => {
    setShowConfirmSaveBeforeNew(false);
    setShowNewMatchDialog(true);
  };

  const confirmDelete = () => {
    if (showDeleteConfirm) {
      const updated = savedMatches.filter(m => m.id !== showDeleteConfirm);
      setSavedMatches(updated);
      localStorage.setItem('volleyballMatches', JSON.stringify(updated));
      setShowDeleteConfirm(null);
      setAlertMessage('✅ Wedstrijd verwijderd');
      setTimeout(() => setAlertMessage(null), 2000);
    }
  };

  const startNewMatch = () => {
    // Check of er een actieve wedstrijd is
    const hasActiveMatch = homeScore > 0 || awayScore > 0 || sets.home > 0 || sets.away > 0;
    
    if (hasActiveMatch) {
      setShowConfirmSaveBeforeNew(true);
    } else {
      setShowNewMatchDialog(true);
    }
    
    setMenuOpen(false);
  };

  const rotateHome = () => {
    const newLineup = {
      1: homeLineup[2],
      2: homeLineup[3],
      3: homeLineup[4],
      4: homeLineup[5],
      5: homeLineup[6],
      6: homeLineup[1],
      libero: homeLineup.libero
    };
    
    setHomeLineup(newLineup);
    setInServicePosition(true); // Na rotatie weer in service positie
  };

  const rotateAway = () => {
    setAwayLineup({
      1: awayLineup[2],
      2: awayLineup[3],
      3: awayLineup[4],
      4: awayLineup[5],
      5: awayLineup[6],
      6: awayLineup[1]
    });
  };

  const scorePoint = (team, x, y) => {
    if (setEnded || matchEnded) return;
    
    // Na eerste contact gaan we naar rally positie
    setInServicePosition(false);
    
    setShowPointTypePopup({ team, x, y });
  };

  const confirmPointType = (type) => {
    const { team, x, y } = showPointTypePopup;
    
    setHeatmapData(h => [...h, { team, x, y, type }]);
    setPointStats(prev => ({
      ...prev,
      [team]: { ...prev[team], [type]: prev[team][type] + 1 }
    }));
    
    let newHome = homeScore, newAway = awayScore;
    if (team === 'home') {
      newHome = homeScore + 1;
      setHomeScore(newHome);
      setScoreHistory(h => [...h, { score: `${newHome}-${awayScore}`, team, type }]);
    } else {
      newAway = awayScore + 1;
      setAwayScore(newAway);
      setScoreHistory(h => [...h, { score: `${homeScore}-${newAway}`, team, type }]);
    }
    
    if (team !== servingTeam) {
      team === 'home' ? rotateHome() : rotateAway();
      setServingTeam(team);
    } else {
      setInServicePosition(true); // Blijf serveren = terug naar service positie
    }
    
    const isSet5 = sets.home === 2 && sets.away === 2;
    const target = isSet5 ? 15 : 25;
    if (newHome >= target && newHome - newAway >= 2) endSet('home');
    if (newAway >= target && newAway - newHome >= 2) endSet('away');
    
    setShowPointTypePopup(null);
  };

  const endSet = (winner) => {
    const newSets = winner === 'home' ? { home: sets.home + 1, away: sets.away } : { home: sets.home, away: sets.away + 1 };
    setSets(newSets);
    setSetEnded(true);
    setSetWinner(winner);
    if (heatmapData.length > 0) {
      setSavedHeatmaps([...savedHeatmaps, {
        setNumber: sets.home + sets.away + 1,
        data: heatmapData,
        finalScore: `${homeScore}-${awayScore}`,
        winner
      }]);
    }
    
    const totalSets = newSets.home + newSets.away;
    
    // Best of 5: altijd 4 sets (tenzij iemand 3-0 of 3-1 wint), 5e set bij 2-2
    // Winnen kan: 3-0, 3-1, 3-2
    if (newSets.home === 3 || newSets.away === 3) {
      // Iemand heeft 3 sets gewonnen
      setMatchEnded(true);
      setMatchWinner(newSets.home === 3 ? 'home' : 'away');
      setShowSaveDialog(true);
    } else if (totalSets === 4 && newSets.home === 2 && newSets.away === 2) {
      // Na 4 sets is het 2-2, speel 5e set
      setShowLineupConfirm(true);
    } else {
      // Ga door naar volgende set
      setShowLineupConfirm(true);
    }
  };

  const startNewSet = (keepLineup) => {
    setHomeScore(0); 
    setAwayScore(0); 
    setScoreHistory([]); 
    setHeatmapData([]);
    setHomeTimeouts([]); 
    setAwayTimeouts([]); 
    setSetEnded(false); 
    setSetWinner(null);
    setShowLineupConfirm(false); 
    setSubstitutions([]);
    setLiberoSubHistory([]);
    setPointStats({ home: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 }, away: { direct: 0, sideout: 0, block: 0, attack: 0, error: 0 } });
    setServiceFaultStats({ home: [], away: [] });
    setInServicePosition(true);
    
    if (sets.home === 2 && sets.away === 2) {
      setShowServingTeamDialog(true);
    } else {
      setServingTeam('home');
    }
    
    if (keepLineup) {
      setHomeLineup(startingHomeLineup);
      setAwayLineup(startingAwayLineup);
    } else {
      setMenuOpen(true);
      setActiveTab('lineup');
    }
  };

  const takeTimeout = (team) => {
    const score = `${homeScore}-${awayScore}`;
    if (team === 'home') {
      if (homeTimeouts.length >= 2) {
        setAlertMessage('⚠️ Maximum 2 timeouts per set (NeVoBo regel)');
        return;
      }
      setHomeTimeouts([...homeTimeouts, score]);
    } else {
      if (awayTimeouts.length >= 2) {
        setAlertMessage('⚠️ Maximum 2 timeouts per set (NeVoBo regel)');
        return;
      }
      setAwayTimeouts([...awayTimeouts, score]);
    }
  };

  const serviceFault = (team) => {
    if (team !== servingTeam) {
      setAlertMessage('⚠️ Alleen het serverende team kan een servicefout maken!');
      return;
    }
    
    // Bepaal wie er serveert (positie 1)
    const lineup = team === 'home' ? homeLineup : awayLineup;
    const servingPlayerId = lineup[1];
    const servingPlayer = team === 'home' 
      ? players.find(p => p.id === servingPlayerId)
      : { id: servingPlayerId, number: servingPlayerId, name: `Speler ${servingPlayerId}` };
    
    const scoringTeam = team === 'home' ? 'away' : 'home';
    setShowServiceFaultPopup({ 
      team: scoringTeam, 
      faultTeam: team,
      servingPlayer,
      x: 50, 
      y: 50 
    });
  };

  const confirmServiceFault = (faultType) => {
    const { team, faultTeam, servingPlayer, x, y } = showServiceFaultPopup;
    
    // Registreer servicefout
    const faultRecord = {
      player: servingPlayer,
      type: faultType,
      score: `${homeScore}-${awayScore}`,
      timestamp: Date.now()
    };
    
    setServiceFaultStats(prev => ({
      ...prev,
      [faultTeam]: [...prev[faultTeam], faultRecord]
    }));
    
    // Score punt voor tegenstander
    setHeatmapData(h => [...h, { team, x, y, type: 'servicefault', faultType }]);
    setPointStats(prev => ({
      ...prev,
      [team]: { ...prev[team], error: prev[team].error + 1 }
    }));
    
    let newHome = homeScore, newAway = awayScore;
    if (team === 'home') {
      newHome = homeScore + 1;
      setHomeScore(newHome);
      setScoreHistory(h => [...h, { score: `${newHome}-${awayScore}`, team, type: 'servicefault', faultType }]);
    } else {
      newAway = awayScore + 1;
      setAwayScore(newAway);
      setScoreHistory(h => [...h, { score: `${homeScore}-${newAway}`, team, type: 'servicefault', faultType }]);
    }
    
    // Wissel van service
    if (team !== servingTeam) {
      team === 'home' ? rotateHome() : rotateAway();
      setServingTeam(team);
    } else {
      setInServicePosition(true);
    }
    
    const isSet5 = sets.home === 2 && sets.away === 2;
    const target = isSet5 ? 15 : 25;
    if (newHome >= target && newHome - newAway >= 2) endSet('home');
    if (newAway >= target && newAway - newHome >= 2) endSet('away');
    
    setShowServiceFaultPopup(null);
  };

  const makeSubstitution = (fieldPlayerId) => {
    if (!selectedBenchPlayer) return;
    
    const validation = validateSubstitution(selectedBenchPlayer, fieldPlayerId);
    
    if (!validation.valid) {
      setSubError(validation.reason);
      setTimeout(() => setSubError(null), 3000);
      return;
    }
    
    const pos = Object.entries(homeLineup).find(([, id]) => id === fieldPlayerId)?.[0];
    if (!pos || pos === 'libero') return;
    
    // Voer wissel uit
    setHomeLineup({ ...homeLineup, [pos]: selectedBenchPlayer });
    setSubstitutions([...substitutions, { 
      playerOut: fieldPlayerId, 
      playerIn: selectedBenchPlayer, 
      score: `${homeScore}-${awayScore}`,
      isLibero: validation.automatic
    }]);
    
    // Track libero wissels apart
    const playerIn = players.find(p => p.id === selectedBenchPlayer);
    if (playerIn?.isLibero) {
      setLiberoSubHistory([...liberoSubHistory, {
        liberoId: selectedBenchPlayer,
        playerOut: fieldPlayerId,
        type: 'in',
        score: `${homeScore}-${awayScore}`
      }]);
    }
    
    setPulsingPlayer(selectedBenchPlayer);
    setTimeout(() => setPulsingPlayer(null), 5000);
    
    setSelectedBenchPlayer(null);
    setSubstitutionMode(false);
    setSidebarExpanded(false);
  };

  // Service Posities (rotatie posities)
  const getServicePositions = () => {
    const positions = {
      1: { bottom: '8%', right: '15%' },
      2: { top: '8%', right: '15%' },
      3: { top: '8%', left: '50%', transform: 'translateX(-50%)' },
      4: { top: '8%', left: '15%' },
      5: { bottom: '8%', left: '15%' },
      6: { bottom: '38%', left: '50%', transform: 'translateX(-50%)' }
    };
    return positions;
  };

  // Rally Posities (5-1 systeem posities)
  const get51RallyPositions = () => {
    if (playSystem !== '5-1') return null;
    
    const setterEntry = Object.entries(homeLineup)
      .filter(([pos]) => pos !== 'libero')
      .find(([, playerId]) => players.find(p => p.id === playerId)?.role === 'setter');
    
    if (!setterEntry) return null;
    
    const setterPos = parseInt(setterEntry[0]);
    
    // Rally posities per rotatie (3 passers systeem)
    const positions = {
      1: {
        1: { bottom: '5%', right: '8%' },
        2: { top: '5%', right: '8%' },
        3: { top: '5%', left: '50%', transform: 'translateX(-50%)' },
        4: { top: '5%', left: '8%' },
        5: { bottom: '5%', left: '8%' },
        6: { bottom: '35%', left: '50%', transform: 'translateX(-50%)' },
      },
      2: {
        1: { bottom: '5%', right: '8%' },
        2: { top: '5%', right: '8%' },
        3: { top: '5%', left: '50%', transform: 'translateX(-50%)' },
        4: { top: '5%', left: '8%' },
        5: { bottom: '5%', left: '8%' },
        6: { bottom: '35%', left: '50%', transform: 'translateX(-50%)' },
      },
      3: {
        1: { bottom: '5%', right: '8%' },
        2: { top: '5%', right: '8%' },
        3: { top: '5%', left: '50%', transform: 'translateX(-50%)' },
        4: { top: '5%', left: '8%' },
        5: { bottom: '5%', left: '8%' },
        6: { bottom: '35%', left: '50%', transform: 'translateX(-50%)' },
      },
      4: {
        1: { bottom: '5%', right: '8%' },
        2: { top: '5%', right: '8%' },
        3: { top: '25%', left: '50%', transform: 'translateX(-50%)' },
        4: { top: '5%', left: '8%' },
        5: { bottom: '5%', left: '8%' },
        6: { bottom: '35%', left: '50%', transform: 'translateX(-50%)' },
      },
      5: {
        1: { bottom: '5%', right: '8%' },
        2: { top: '5%', right: '8%' },
        3: { top: '5%', left: '50%', transform: 'translateX(-50%)' },
        4: { top: '5%', left: '8%' },
        5: { bottom: '5%', left: '25%' },
        6: { bottom: '5%', left: '50%' },
      },
      6: {
        1: { bottom: '5%', right: '8%' },
        2: { top: '5%', right: '8%' },
        3: { top: '25%', left: '50%', transform: 'translateX(-50%)' },
        4: { top: '5%', left: '8%' },
        5: { bottom: '5%', left: '8%' },
        6: { bottom: '35%', left: '50%', transform: 'translateX(-50%)' },
      }
    };
    
    return positions[setterPos] || null;
  };

  const getPositionStyle = (position, isAway = false) => {
    if (!isAway) {
      if (inServicePosition) {
        // Service positie: vaste rotatie posities
        return getServicePositions()[position];
      } else if (playSystem === '5-1') {
        // Rally positie: systeem posities
        const rallyPositions = get51RallyPositions();
        if (rallyPositions && rallyPositions[position]) {
          return rallyPositions[position];
        }
      }
    }
    
    // Tegenstander of fallback
    const positions = getServicePositions();
    if (isAway) {
      const pos = { ...positions[position] };
      if (pos.top) { pos.bottom = pos.top; delete pos.top; }
      else if (pos.bottom) { pos.top = pos.bottom; delete pos.bottom; }
      return pos;
    }
    return positions[position];
  };

  const getSetterInfo = () => {
    if (playSystem !== '5-1' || inServicePosition) return null;
    
    const setterPos = Object.entries(homeLineup)
      .filter(([pos]) => pos !== 'libero')
      .find(([, playerId]) => {
        const player = players.find(p => p.id === playerId);
        return player?.role === 'setter';
      });
    
    if (!setterPos) return null;
    
    const pos = parseInt(setterPos[0]);
    const isBackRow = pos === 1 || pos === 6 || pos === 5;
    const isFrontRowPenetration = pos === 4;
    
    return {
      position: pos,
      isBackRow,
      needsPenetration: isBackRow || isFrontRowPenetration,
      targetPosition: 2.5
    };
  };

  const getRoleLabel = (role) => {
    const labels = {
      'setter': 'SPE',
      'opposite': 'DIA',
      'middle': 'MID',
      'outside': 'PL',
      'libero': 'L'
    };
    return labels[role] || '';
  };

  // Analyse berekeningen
  const getAnalysisData = () => {
    const totalPoints = homeScore + awayScore;
    const homeWinPercentage = totalPoints > 0 ? ((homeScore / totalPoints) * 100).toFixed(1) : 0;
    
    const homeTotalPointTypes = Object.values(pointStats.home).reduce((a, b) => a + b, 0);
    const awayTotalPointTypes = Object.values(pointStats.away).reduce((a, b) => a + b, 0);
    
    const sideoutPercentage = homeTotalPointTypes > 0 
      ? ((pointStats.home.sideout / homeTotalPointTypes) * 100).toFixed(1)
      : 0;
    
    const attackEfficiency = homeTotalPointTypes > 0
      ? (((pointStats.home.attack + pointStats.home.block) / homeTotalPointTypes) * 100).toFixed(1)
      : 0;
    
    const serveEfficiency = homeTotalPointTypes > 0
      ? ((pointStats.home.direct / homeTotalPointTypes) * 100).toFixed(1)
      : 0;

    return {
      homeWinPercentage,
      sideoutPercentage,
      attackEfficiency,
      serveEfficiency,
      totalRallies: scoreHistory.length,
      longestRally: Math.max(...heatmapData.map((_, i) => i + 1), 0),
      timeoutsUsed: homeTimeouts.length,
      substitutionsUsed: substitutions.length
    };
  };

  const renderPlayer = (playerId, position, isAway) => {
    const player = players.find(p => p.id === playerId);
    const sizeClass = isAway 
      ? "w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20"
      : "w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24";
    
    const shouldPulse = !isAway && pulsingPlayer === playerId;
    
    const isServing = position === 1 && (
      (isAway && servingTeam === 'away') || 
      (!isAway && servingTeam === 'home')
    );
    
    if (!player && playerId) {
      return (
        <div key={position} className={`absolute ${sizeClass} flex items-center justify-center cursor-pointer z-20 transition-all duration-700 ease-out`} 
          style={getPositionStyle(position, isAway)}
          onClick={(e) => {
            e.stopPropagation();
            if (substitutionMode && !isAway && selectedBenchPlayer) {
              makeSubstitution(playerId);
            } else if (!substitutionMode && !showPointTypePopup) {
              const team = isAway ? 'home' : 'away';
              const style = getPositionStyle(position, isAway);
              const x = parseInt(style.left || style.right || 50);
              const y = parseInt(style.top || style.bottom || 50);
              scorePoint(team, x, y);
            }
          }}>
          <svg viewBox="0 0 24 24" className="w-full h-full">
            <path d="M8 3l4 2 4-2 5 3-3 5v10a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V11L3 6l5-3z" fill="#2563eb" stroke="white" strokeWidth="0.5"/>
            <text x="12" y="15" textAnchor="middle" fill="white" fontSize="7" fontWeight="bold">{playerId}</text>
          </svg>
          {isServing && (
            <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 z-30">
              <svg viewBox="0 0 100 100" className="w-6 h-6 animate-bounce drop-shadow-lg">
                <defs>
                  <radialGradient id="ballGradient1" cx="35%" cy="35%">
                    <stop offset="0%" stopColor="#ffffff" />
                    <stop offset="50%" stopColor="#fef3c7" />
                    <stop offset="100%" stopColor="#fbbf24" />
                  </radialGradient>
                </defs>
                <circle cx="50" cy="50" r="45" fill="url(#ballGradient1)" stroke="#f59e0b" strokeWidth="2"/>
                <path d="M 20 30 Q 15 50, 20 70 Q 35 75, 50 70 Q 35 50, 50 30 Q 35 25, 20 30 Z" 
                      fill="none" stroke="#d97706" strokeWidth="2.5" opacity="0.8"/>
                <path d="M 80 30 Q 85 50, 80 70 Q 65 75, 50 70 Q 65 50, 50 30 Q 65 25, 80 30 Z" 
                      fill="none" stroke="#d97706" strokeWidth="2.5" opacity="0.8"/>
                <path d="M 30 20 Q 50 15, 70 20 Q 75 35, 70 50 Q 50 35, 30 50 Q 25 35, 30 20 Z" 
                      fill="none" stroke="#d97706" strokeWidth="2.5" opacity="0.8"/>
                <ellipse cx="38" cy="38" rx="12" ry="8" fill="white" opacity="0.4"/>
              </svg>
            </div>
          )}
        </div>
      );
    }
    if (!player) return null;

    const shirtColor = player.isLibero ? '#475569' : (isAway ? '#2563eb' : '#dc2626');
    const roleLabel = getRoleLabel(player.role);

    return (
      <div key={position} className={`absolute ${sizeClass} flex items-center justify-center cursor-pointer z-20 transition-all duration-700 ease-out`} 
        style={getPositionStyle(position, isAway)}
        onClick={(e) => {
          e.stopPropagation();
          if (substitutionMode && !isAway && selectedBenchPlayer) {
            makeSubstitution(playerId);
          } else if (!substitutionMode && !showPointTypePopup) {
            const team = isAway ? 'home' : 'away';
            const style = getPositionStyle(position, isAway);
            const x = parseInt(style.left || style.right || 50);
            const y = parseInt(style.top || style.bottom || 50);
            scorePoint(team, x, y);
          }
        }}>
        <svg viewBox="0 0 24 24" className="w-full h-full drop-shadow-lg">
          <path d="M8 3l4 2 4-2 5 3-3 5v10a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V11L3 6l5-3z" fill={shirtColor} stroke="white" strokeWidth="0.5"/>
          <text x="12" y="13" textAnchor="middle" fill="white" fontSize="6" fontWeight="bold">{player.number}</text>
          <text x="12" y="19" textAnchor="middle" fill="white" fontSize="4" fontWeight="bold">{roleLabel}</text>
        </svg>
        {isServing && (
          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 z-30">
            <svg viewBox="0 0 100 100" className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 animate-bounce drop-shadow-lg">
              <defs>
                <radialGradient id="ballGradient2" cx="35%" cy="35%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="50%" stopColor="#fef3c7" />
                  <stop offset="100%" stopColor="#fbbf24" />
                </radialGradient>
              </defs>
              <circle cx="50" cy="50" r="45" fill="url(#ballGradient2)" stroke="#f59e0b" strokeWidth="2"/>
              <path d="M 20 30 Q 15 50, 20 70 Q 35 75, 50 70 Q 35 50, 50 30 Q 35 25, 20 30 Z" 
                    fill="none" stroke="#d97706" strokeWidth="2.5" opacity="0.8"/>
              <path d="M 80 30 Q 85 50, 80 70 Q 65 75, 50 70 Q 65 50, 50 30 Q 65 25, 80 30 Z" 
                    fill="none" stroke="#d97706" strokeWidth="2.5" opacity="0.8"/>
              <path d="M 30 20 Q 50 15, 70 20 Q 75 35, 70 50 Q 50 35, 30 50 Q 25 35, 30 20 Z" 
                    fill="none" stroke="#d97706" strokeWidth="2.5" opacity="0.8"/>
              <ellipse cx="38" cy="38" rx="12" ry="8" fill="white" opacity="0.4"/>
            </svg>
          </div>
        )}
        {shouldPulse && (
          <div className="absolute inset-0 rounded-full border-4 border-yellow-400 animate-ping pointer-events-none" />
        )}
      </div>
    );
  };

  const renderHomeLineup = () => {
    const { libero } = homeLineup;
    
    return [1, 2, 3, 4, 5, 6].map(pos => {
      let player = homeLineup[pos];
      
      // Automatische libero wissel voor middens op achterlijn
      // MAAR NOOIT OP POSITIE 1 (serveren is niet toegestaan voor libero!)
      if (libero && player) {
        const playerData = players.find(p => p.id === player);
        const isBackRow = pos === 5 || pos === 6; // NIET pos 1!
        
        if (playerData?.role === 'middle' && isBackRow) {
          player = libero;
        }
      }
      
      return player ? renderPlayer(player, pos, false) : null;
    });
  };

  const renderAwayLineup = () => [1, 2, 3, 4, 5, 6].map(pos => awayLineup[pos] && renderPlayer(awayLineup[pos], pos, true));

  const fieldPlayers = Object.values(homeLineup).filter((_, i) => i < 6);
  const benchPlayers = players.filter(p => !fieldPlayers.includes(p.id) && p.id !== homeLineup.libero);

  const renderBenchArea = () => {
    const result = [];
    
    // Libero (altijd grijs, niet klikbaar)
    const liberoPlayer = players.find(p => p.id === homeLineup.libero);
    if (liberoPlayer) {
      result.push({ player: liberoPlayer, reason: 'libero' });
    }
    
    // Bank spelers (klikbaar voor wissels)
    benchPlayers.forEach(player => {
      result.push({ player, reason: 'bench' });
    });
    
    return result;
  };

  const analysis = getAnalysisData();

  return (
    <div 
      className="h-screen w-screen bg-blue-900 text-white overflow-hidden flex flex-col" 
      style={{ 
        cursor: (isResizing || isResizingCompact) ? 'col-resize' : 'default',
        userSelect: (isResizing || isResizingCompact) ? 'none' : 'auto'
      }}
    >
      {confetti.map(c => <div key={c.id} className="fixed w-3 h-3 bg-yellow-400 rounded-full pointer-events-none z-50 animate-ping" style={{ left: `${c.left}%`, top: '-10px', animationDelay: `${c.delay}s` }} />)}

      <header className="bg-gray-800 p-3 sm:p-4 flex justify-between items-center flex-shrink-0">
        <div className="flex-1">
          <div className="text-lg sm:text-xl font-bold">VCV Volleybal Tracker</div>
          {opponentName && <div className="text-xs text-gray-400">vs {opponentName} ({matchDate})</div>}
          {!inServicePosition && (
            <div className="text-xs text-yellow-400 mt-1">⚡ RALLY POSITIE</div>
          )}
        </div>
        <button onClick={() => setMenuOpen(!menuOpen)} className="p-2 hover:bg-gray-700 rounded">
          {menuOpen ? <X size={32} className="sm:w-6 sm:h-6" /> : <Menu size={32} className="sm:w-6 sm:h-6" />}
        </button>
      </header>

      <div 
        className={`fixed top-0 right-0 h-full bg-gray-800 shadow-lg transform transition-transform z-50 ${menuOpen ? 'translate-x-0' : 'translate-x-full'} overflow-y-auto`}
        style={{ width: windowWidth < 640 ? `${windowWidth * 0.85}px` : `${sidebarWidth}px` }}
      >
        {/* Resize Handle */}
        <div 
          className="absolute left-0 top-0 bottom-0 w-2 sm:w-1 bg-gray-600 hover:bg-blue-500 cursor-col-resize z-50 group active:bg-blue-500"
          onMouseDown={() => setIsResizing(true)}
          onTouchStart={() => setIsResizing(true)}
        >
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-6 sm:w-4 h-16 sm:h-12 bg-gray-600 group-hover:bg-blue-500 group-active:bg-blue-500 rounded-r flex items-center justify-center">
            <div className="w-0.5 h-8 sm:h-6 bg-gray-400 mx-0.5"></div>
            <div className="w-0.5 h-8 sm:h-6 bg-gray-400 mx-0.5"></div>
          </div>
        </div>
        <div className="p-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Menu</h2>
            <button onClick={() => setMenuOpen(false)}><X size={24} /></button>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-4">
            {[
              ['players', Users, 'Spelers'], 
              ['lineup', Grid, 'Opstelling'], 
              ['system', Grid, 'Systeem'],
              ['subs', RefreshCw, 'Wissels'],
              ['heatmap', Grid, 'Heatmap'],
              ['analysis', TrendingUp, 'Analyse'],
              ['stats', Grid, 'Stats'],
              ['matches', Grid, 'Wedstrijden'],
              ['rules', AlertTriangle, 'Regels']
            ].map(([tab, Icon, label]) => (
              <button key={tab} onClick={() => setActiveTab(tab)} className={`p-2 rounded text-xs ${activeTab === tab ? 'bg-blue-600' : 'bg-gray-700'}`}>
                <Icon size={14} className="inline mr-1" />{label}
              </button>
            ))}
          </div>

          {activeTab === 'players' && (
            <div>
              <h3 className="font-bold mb-2">Spelers</h3>
              {players.map(p => (
                <div key={p.id} className="bg-gray-700 p-2 mb-2 rounded text-sm">
                  <div className="flex gap-2 mb-1">
                    <input type="text" value={p.name} onChange={(e) => updatePlayer(p.id, 'name', e.target.value)} className="flex-1 bg-gray-600 p-1 rounded text-white text-sm" />
                    <input type="number" value={p.number} onChange={(e) => updatePlayer(p.id, 'number', parseInt(e.target.value))} className="w-14 bg-gray-600 p-1 rounded text-white text-sm" />
                  </div>
                  <div className="flex gap-2 mb-1">
                    <select 
                      value={p.role || 'outside'} 
                      onChange={(e) => updatePlayer(p.id, 'role', e.target.value)}
                      className="flex-1 bg-gray-600 p-1 rounded text-white text-xs"
                      disabled={p.isLibero}
                    >
                      <option value="setter">Spelverdeler (SPE)</option>
                      <option value="outside">Passer/Loper (PL)</option>
                      <option value="middle">Midden (MID)</option>
                      <option value="opposite">Diagonaal (DIA)</option>
                      <option value="libero">Libero (L)</option>
                    </select>
                  </div>
                  <div className="flex gap-2">
                    <label className="flex items-center gap-1 flex-1 text-xs">
                      <input type="checkbox" checked={p.isLibero || false} onChange={(e) => updatePlayer(p.id, 'isLibero', e.target.checked)} />
                      Libero
                    </label>
                    <button onClick={() => removePlayer(p.id)} className="bg-red-600 px-2 py-1 rounded text-xs hover:bg-red-700">Verwijder</button>
                  </div>
                </div>
              ))}
              <button onClick={addPlayer} className="w-full bg-green-600 p-2 rounded text-sm hover:bg-green-700 mt-2">+ Speler Toevoegen</button>
            </div>
          )}

          {activeTab === 'lineup' && (
            <div>
              <h3 className="font-bold mb-2 text-sm">Tegenstander Info</h3>
              <div className="mb-3">
                <label className="block text-xs mb-1">Tegenstander Naam</label>
                <input 
                  type="text" 
                  value={opponentName} 
                  onChange={(e) => setOpponentName(e.target.value)} 
                  placeholder="Naam tegenstander" 
                  className="w-full bg-gray-700 p-2 rounded text-white text-sm mb-2"
                />
                <label className="block text-xs mb-1">Wedstrijd Datum</label>
                <input 
                  type="date" 
                  value={matchDate} 
                  onChange={(e) => setMatchDate(e.target.value)} 
                  className="w-full bg-gray-700 p-2 rounded text-white text-sm"
                />
              </div>

              <h3 className="font-bold mb-2 text-sm">Ons Team</h3>
              {[1, 2, 3, 4, 5, 6].map(pos => (
                <div key={pos} className="mb-1">
                  <label className="block text-xs mb-1">Pos {pos}</label>
                  <select value={homeLineup[pos] || ''} onChange={(e) => updateLineup('home', pos, parseInt(e.target.value))} className="w-full bg-gray-700 p-1 rounded text-white text-sm">
                    <option value="">Selecteer</option>
                    {players.filter(p => !p.isLibero).map(p => <option key={p.id} value={p.id}>{p.name} (#{p.number}) - {getRoleLabel(p.role)}</option>)}
                  </select>
                </div>
              ))}
              <div className="mb-1">
                <label className="block text-xs mb-1">Libero</label>
                <select value={homeLineup.libero || ''} onChange={(e) => updateLineup('home', 'libero', parseInt(e.target.value))} className="w-full bg-gray-700 p-1 rounded text-white text-sm">
                  <option value="">Selecteer</option>
                  {players.filter(p => p.isLibero).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <button onClick={confirmLineup} className="w-full bg-green-600 p-3 rounded font-bold mb-3 text-sm">
                ✓ BEVESTIG OPSTELLING
              </button>

              <h3 className="font-bold mb-2 mt-3 text-sm">Tegenstander</h3>
              {[1, 2, 3, 4, 5, 6].map(pos => (
                <div key={pos} className="mb-1">
                  <label className="block text-xs mb-1">Pos {pos}</label>
                  <input type="number" value={awayLineup[pos] || ''} onChange={(e) => updateLineup('away', pos, e.target.value ? parseInt(e.target.value) : null)} placeholder="Nr" className="w-full bg-gray-700 p-1 rounded text-white text-sm" />
                </div>
              ))}
              <button onClick={confirmLineup} className="w-full bg-green-600 p-3 rounded font-bold mt-2 text-sm">
                ✓ BEVESTIG OPSTELLING
              </button>
            </div>
          )}

          {activeTab === 'system' && (
            <div>
              <h3 className="font-bold mb-3 text-sm">Speelsysteem</h3>
              
              <div className="mb-4">
                <label className="block text-xs mb-2 text-gray-400">Selecteer Systeem</label>
                <select 
                  value={playSystem} 
                  onChange={(e) => setPlaySystem(e.target.value)}
                  className="w-full bg-gray-700 p-2 rounded text-white text-sm"
                >
                  <option value="5-1">5-1 Systeem</option>
                  <option value="4-2">4-2 Systeem</option>
                  <option value="6-2">6-2 Systeem</option>
                </select>
              </div>

              <div className="bg-blue-900 p-3 rounded text-xs mb-3">
                <h4 className="font-bold mb-2">Service vs Rally Posities:</h4>
                <p className="mb-2">🔵 <strong>Service Positie</strong>: Rotatie posities voor opslag</p>
                <p className="mb-2">⚡ <strong>Rally Positie</strong>: Systeem posities tijdens rally</p>
                <p className="text-yellow-300">App schakelt automatisch tussen posities!</p>
              </div>

              <div className="bg-blue-900 p-3 rounded text-xs">
                <h4 className="font-bold mb-2">Rol Labels:</h4>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold">SPE</span>
                    <span>= Spelverdeler</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">DIA</span>
                    <span>= Diagonaal</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">MID</span>
                    <span>= Midden</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">PL</span>
                    <span>= Passer/Loper</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">L</span>
                    <span>= Libero</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'analysis' && (
            <div>
              <h3 className="font-bold mb-3 text-sm">📊 Wedstrijd Analyse</h3>
              
              {/* Set Selector */}
              <div className="bg-gray-700 p-2 rounded mb-3">
                <div className="flex gap-1 text-[10px]">
                  <button 
                    onClick={() => setSelectedAnalysisSet('current')}
                    className={`flex-1 py-1 rounded ${selectedAnalysisSet === 'current' ? 'bg-blue-600' : 'bg-gray-600'}`}
                  >
                    Huidige Set
                  </button>
                  <button 
                    onClick={() => setSelectedAnalysisSet('overall')}
                    className={`flex-1 py-1 rounded ${selectedAnalysisSet === 'overall' ? 'bg-green-600' : 'bg-gray-600'}`}
                  >
                    Overall
                  </button>
                </div>
                {savedHeatmaps.length > 0 && (
                  <div className="flex gap-1 mt-1 flex-wrap">
                    {savedHeatmaps.map((hm, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedAnalysisSet(idx)}
                        className={`px-2 py-1 rounded text-[9px] ${selectedAnalysisSet === idx ? 'bg-yellow-600' : 'bg-gray-600'}`}
                      >
                        Set {idx + 1}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="bg-gray-700 p-3 rounded mb-3">
                <h4 className="text-sm font-semibold mb-2 text-green-400">
                  Performance {selectedAnalysisSet === 'current' ? '(Huidige Set)' : selectedAnalysisSet === 'overall' ? '(Overall)' : `(Set ${selectedAnalysisSet + 1})`}
                </h4>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Win %:</span>
                    <span className="font-bold">{analysis.homeWinPercentage}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sideout %:</span>
                    <span className="font-bold">{analysis.sideoutPercentage}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Aanval %:</span>
                    <span className="font-bold">{analysis.attackEfficiency}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Service %:</span>
                    <span className="font-bold">{analysis.serveEfficiency}%</span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-700 p-3 rounded mb-3">
                <h4 className="text-sm font-semibold mb-2 text-blue-400">Statistieken</h4>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Totaal Rally's:</span>
                    <span className="font-bold">{analysis.totalRallies}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Timeouts:</span>
                    <span className="font-bold">{analysis.timeoutsUsed}/2</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Wissels:</span>
                    <span className="font-bold">{analysis.substitutionsUsed}/6</span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-700 p-3 rounded mb-3">
                <h4 className="text-sm font-semibold mb-2 text-yellow-400">Punten Verdeling</h4>
                <div className="text-xs space-y-2">
                  {Object.entries(pointStats.home).map(([type, count]) => (
                    <div key={type} className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-600 rounded-full h-4 overflow-hidden">
                        <div 
                          className="bg-red-500 h-full transition-all duration-500"
                          style={{ width: `${count > 0 ? (count / Object.values(pointStats.home).reduce((a,b) => a+b, 0) * 100) : 0}%` }}
                        />
                      </div>
                      <span className="w-16 text-right">{type}: {count}</span>
                    </div>
                  ))}
                </div>
              </div>

              {serviceFaultStats.home.length > 0 && (
                <div className="bg-gray-700 p-3 rounded mb-3">
                  <h4 className="text-sm font-semibold mb-2 text-red-400">⚠️ Service Fouten</h4>
                  <div className="text-xs space-y-2">
                    <div className="flex justify-between mb-1">
                      <span>Totaal fouten:</span>
                      <span className="font-bold">{serviceFaultStats.home.length}</span>
                    </div>
                    
                    <div className="border-t border-gray-600 pt-2 space-y-1">
                      <div className="flex justify-between">
                        <span>🥅 In het Net:</span>
                        <span className="font-bold">{serviceFaultStats.home.filter(f => f.type === 'net').length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>↗️ Bal Uit:</span>
                        <span className="font-bold">{serviceFaultStats.home.filter(f => f.type === 'out').length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>👟 Voetfout:</span>
                        <span className="font-bold">{serviceFaultStats.home.filter(f => f.type === 'footfault').length}</span>
                      </div>
                    </div>

                    <div className="border-t border-gray-600 pt-2 mt-2">
                      <div className="font-semibold mb-1">Per Speler:</div>
                      {Array.from(new Set(serviceFaultStats.home.map(f => f.player.id))).map(playerId => {
                        const playerFaults = serviceFaultStats.home.filter(f => f.player.id === playerId);
                        const player = playerFaults[0].player;
                        const netCount = playerFaults.filter(f => f.type === 'net').length;
                        const outCount = playerFaults.filter(f => f.type === 'out').length;
                        const footCount = playerFaults.filter(f => f.type === 'footfault').length;
                        
                        return (
                          <div key={playerId} className="mb-2 pb-2 border-b border-gray-600 last:border-0">
                            <div className="flex justify-between text-[10px] font-bold mb-1">
                              <span>#{player.number} {player.name}</span>
                              <span>{playerFaults.length}x totaal</span>
                            </div>
                            <div className="text-[9px] text-gray-400 ml-2 space-y-0.5">
                              {netCount > 0 && <div>🥅 In het Net: {netCount}x</div>}
                              {outCount > 0 && <div>↗️ Bal Uit: {outCount}x</div>}
                              {footCount > 0 && <div>👟 Voetfout: {footCount}x</div>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'rules' && (
            <div>
              <h3 className="font-bold mb-3 text-sm">⚠️ NeVoBo Regels</h3>
              
              <div className="bg-orange-900 p-3 rounded mb-3">
                <h4 className="text-sm font-semibold mb-2">Libero Regels</h4>
                <ul className="text-xs space-y-1 list-disc list-inside">
                  <li>⚠️ MAG NIET SERVEREN (pos 1 verboden!)</li>
                  <li>Alleen wisselen met achterlijn pos 5 en 6</li>
                  <li>Mag niet aanvallen vanaf voorlijn</li>
                  <li>Terugwisselen met dezelfde speler</li>
                  <li>Onbeperkt aantal wissels</li>
                  <li>Automatisch voor middens op pos 5/6</li>
                </ul>
              </div>

              <div className="bg-blue-900 p-3 rounded mb-3">
                <h4 className="text-sm font-semibold mb-2">Wissel Regels</h4>
                <ul className="text-xs space-y-1 list-disc list-inside">
                  <li>Maximum 6 wissels per set</li>
                  <li>Alleen terugwisselen met zelfde partner</li>
                  <li>Libero wissels tellen niet mee</li>
                </ul>
              </div>

              <div className="bg-green-900 p-3 rounded mb-3">
                <h4 className="text-sm font-semibold mb-2">Timeout Regels</h4>
                <ul className="text-xs space-y-1 list-disc list-inside">
                  <li>Maximum 2 timeouts per set</li>
                  <li>Duur: 30 seconden</li>
                  <li>Technische timeout bij 8 en 16 punten (1e-4e set)</li>
                </ul>
              </div>

              <div className="bg-purple-900 p-3 rounded">
                <h4 className="text-sm font-semibold mb-2">Set Regels</h4>
                <ul className="text-xs space-y-1 list-disc list-inside">
                  <li>Set 1-4: Tot 25 punten (min. 2 verschil)</li>
                  <li>Set 5: Tot 15 punten (min. 2 verschil)</li>
                  <li>Bij 2-2: wisselen van speelhelft bij 8 punten</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'subs' && (
            <div>
              <h3 className="font-bold mb-2 text-sm">Wissels</h3>
              <button 
                onClick={() => { 
                  setSubstitutionMode(!substitutionMode); 
                  setSelectedBenchPlayer(null); 
                }} 
                className={`w-full p-2 rounded mb-3 text-sm ${substitutionMode ? 'bg-yellow-600' : 'bg-blue-600'}`}
              >
                {substitutionMode ? 'Annuleer Wissel' : 'Start Wissel'}
              </button>
              
              {substitutionMode && (
                <div className="bg-gray-700 p-2 rounded mb-3 text-xs">
                  <p>1. Kies wisselspeler hieronder</p>
                  <p>2. Klik op veldspeler om te wisselen</p>
                  {selectedBenchPlayer && (
                    <p className="text-green-400 mt-1">✓ {players.find(p => p.id === selectedBenchPlayer)?.name} geselecteerd</p>
                  )}
                </div>
              )}

              <p className="text-xs text-gray-400 mb-2">{6 - substitutions.length} wissels over deze set</p>
              
              <h4 className="font-bold text-xs mb-2">Wisselspelers:</h4>
              {benchPlayers.map(p => {
                const roleLabel = getRoleLabel(p.role);
                return (
                  <button 
                    key={p.id}
                    onClick={() => {
                      setSubstitutionMode(true);
                      setSelectedBenchPlayer(p.id);
                    }}
                    className={`w-full p-2 mb-2 rounded text-left text-sm ${selectedBenchPlayer === p.id ? 'bg-green-600' : 'bg-gray-700'}`}
                  >
                    <div className="flex items-center justify-between">
                      <span>#{p.number} {p.name}</span>
                      <span className="text-xs text-gray-300">{roleLabel}</span>
                    </div>
                  </button>
                );
              })}

              {substitutions.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-600">
                  <h4 className="font-bold text-xs mb-2">Wissels deze set:</h4>
                  {substitutions.map((sub, i) => {
                    const outPlayer = players.find(p => p.id === sub.playerOut);
                    const inPlayer = players.find(p => p.id === sub.playerIn);
                    return (
                      <div key={i} className="bg-gray-700 p-2 mb-1 rounded text-xs">
                        <span className="text-red-400">#{outPlayer?.number} {outPlayer?.name}</span>
                        {' → '}
                        <span className="text-green-400">#{inPlayer?.number} {inPlayer?.name}</span>
                        <span className="text-gray-400 ml-2">({sub.score})</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === 'heatmap' && (
            <div>
              <h3 className="font-bold mb-2 text-sm">Heatmap Analyse</h3>
              
              {savedHeatmaps.length > 0 && (
                <div className="bg-blue-900 p-3 rounded mb-3">
                  <p className="text-xs font-bold text-yellow-400 mb-1">📊 Review Modus Actief</p>
                  <p className="text-xs text-gray-300">Bekijk opgeslagen heatmaps van sets hieronder</p>
                </div>
              )}
              
              <div className="bg-blue-900 p-2 rounded mb-2 text-xs">
                <p>Overlay: {showHeatmapOverlay !== null ? `Set ${savedHeatmaps[showHeatmapOverlay]?.setNumber}` : 'Geen'}</p>
                <p>Opgeslagen: {savedHeatmaps.length} sets</p>
              </div>
              
              <div className="mb-4">
                <h4 className="text-sm font-semibold mb-2 text-gray-300">Huidige Set</h4>
                <div className="bg-gray-700 p-3 rounded">
                  <p className="text-xs mb-1">Ons: <span className="text-red-400">{heatmapData.filter(d => d.team === 'home').length}</span></p>
                  <p className="text-xs">Tegenstander: <span className="text-blue-400">{heatmapData.filter(d => d.team === 'away').length}</span></p>
                </div>
              </div>
              
              {savedHeatmaps.length > 0 ? (
                <div>
                  <h4 className="text-sm font-semibold mb-2 text-gray-300">Vorige Sets</h4>
                  {savedHeatmaps.map((hm, i) => (
                    <button 
                      key={i} 
                      onClick={() => setShowHeatmapOverlay(showHeatmapOverlay === i ? null : i)}
                      className={`w-full p-2 mb-2 rounded text-xs text-left ${showHeatmapOverlay === i ? 'bg-yellow-600 ring-2 ring-yellow-400' : 'bg-gray-700'}`}
                    >
                      <div className="flex justify-between">
                        <span className="font-bold">Set {hm.setNumber}</span>
                        <span>{hm.winner === 'home' ? '✓' : '✗'}</span>
                      </div>
                      <div className="text-gray-300 mt-1">Stand: {hm.finalScore}</div>
                      {showHeatmapOverlay === i && <div className="text-yellow-300 mt-2 font-bold">👁️ ZICHTBAAR</div>}
                    </button>
                  ))}
                  {showHeatmapOverlay !== null && (
                    <div className="bg-yellow-900 p-2 rounded mt-2 text-xs">
                      <p className="text-yellow-200 font-bold">GEEL = Oude set</p>
                      <p className="text-yellow-200">ROOD/BLAUW = Nu</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-gray-700 p-3 rounded text-xs">Geen opgeslagen heatmaps</div>
              )}
            </div>
          )}

          {activeTab === 'stats' && (
            <div>
              <h3 className="font-bold mb-2 text-sm">Punt Statistieken</h3>
              
              {savedHeatmaps.length > 0 && (
                <div className="bg-blue-900 p-3 rounded mb-3">
                  <p className="text-xs font-bold text-yellow-400 mb-1">📊 Review Modus</p>
                  <p className="text-xs text-gray-300">Statistieken van geladen wedstrijd</p>
                  <p className="text-xs text-white mt-2">Eindstand: <strong>{sets.home} - {sets.away}</strong></p>
                  <p className="text-xs text-white">Resultaat: <strong>{matchWinner === 'home' ? '🏆 Gewonnen' : matchWinner === 'away' ? '😢 Verloren' : '⏸️ Bezig'}</strong></p>
                </div>
              )}
              
              <div className="bg-gray-700 p-3 rounded mb-3">
                <h4 className="text-sm font-semibold mb-2 text-red-400">Ons Team</h4>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Direct (Ace):</span>
                    <span className="font-bold">{pointStats.home.direct}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sideout:</span>
                    <span className="font-bold">{pointStats.home.sideout}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Blok:</span>
                    <span className="font-bold">{pointStats.home.block}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Aanval:</span>
                    <span className="font-bold">{pointStats.home.attack}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tegenstander fout:</span>
                    <span className="font-bold">{pointStats.home.error}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-600 pt-1 mt-1">
                    <span className="font-bold">Totaal:</span>
                    <span className="font-bold">{Object.values(pointStats.home).reduce((a, b) => a + b, 0)}</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-700 p-3 rounded">
                <h4 className="text-sm font-semibold mb-2 text-blue-400">Tegenstander</h4>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Direct (Ace):</span>
                    <span className="font-bold">{pointStats.away.direct}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sideout:</span>
                    <span className="font-bold">{pointStats.away.sideout}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Blok:</span>
                    <span className="font-bold">{pointStats.away.block}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Aanval:</span>
                    <span className="font-bold">{pointStats.away.attack}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tegenstander fout:</span>
                    <span className="font-bold">{pointStats.away.error}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-600 pt-1 mt-1">
                    <span className="font-bold">Totaal:</span>
                    <span className="font-bold">{Object.values(pointStats.away).reduce((a, b) => a + b, 0)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'matches' && (
            <div>
              <h3 className="font-bold mb-3 text-sm">Wedstrijden Beheer</h3>
              
              <button 
                onClick={startNewMatch} 
                className="w-full bg-green-600 p-3 rounded mb-3 text-sm font-bold hover:bg-green-700"
              >
                ➕ Nieuwe Wedstrijd Starten
              </button>

              <button 
                onClick={() => setShowLoadDialog(true)} 
                className="w-full bg-blue-600 p-3 rounded mb-3 text-sm font-bold hover:bg-blue-700"
              >
                📂 Wedstrijd Laden ({savedMatches.length})
              </button>

              <div className="bg-gray-700 p-3 rounded text-xs mb-3">
                <p className="mb-2">Opgeslagen: <strong className="text-green-400">{savedMatches.length}</strong> wedstrijden</p>
                {savedMatches.length === 0 && (
                  <p className="text-gray-400">Nog geen wedstrijden opgeslagen</p>
                )}
              </div>

              <div className="bg-blue-900 p-3 rounded text-xs">
                <p className="font-bold mb-2">Huidige Wedstrijd:</p>
                <p>Sets: {sets.home} - {sets.away}</p>
                <p>Score: {homeScore} - {awayScore}</p>
                <p>Tegenstander: {opponentName || 'Niet ingevuld'}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {showServingTeamDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4 text-center">🏐 Wie mag serveren?</h3>
            
            <div className="flex gap-4">
              <button 
                onClick={() => setInitialServingTeam('home')} 
                className="flex-1 bg-red-600 p-4 rounded-lg font-bold text-lg hover:bg-red-700"
              >
                🔴 Ons Team
              </button>
              <button 
                onClick={() => setInitialServingTeam('away')} 
                className="flex-1 bg-blue-600 p-4 rounded-lg font-bold text-lg hover:bg-blue-700"
              >
                🔵 Tegenstander
              </button>
            </div>
          </div>
        </div>
      )}

      {alertMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-sm mx-4 text-center">
            <p className="text-lg mb-4">{alertMessage}</p>
            <button 
              onClick={() => setAlertMessage(null)} 
              className="bg-blue-600 px-6 py-2 rounded font-bold hover:bg-blue-700"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {subError && (
        <div className="fixed top-20 right-4 bg-red-600 p-4 rounded-lg shadow-lg z-50 max-w-sm animate-pulse">
          <p className="text-sm font-bold">⚠️ {subError}</p>
        </div>
      )}

      {showPointTypePopup && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-sm">
            <h3 className="text-xl font-bold mb-4 text-center">
              {showPointTypePopup.isServiceFault ? 'Service Fout!' : 'Selecteer Punttype'}
            </h3>
            <p className="text-sm text-gray-400 mb-4 text-center">
              {showPointTypePopup.team === 'home' ? 'Ons Team' : 'Tegenstander'} scoort
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => confirmPointType('direct')} className="bg-blue-600 p-3 rounded font-bold text-sm hover:bg-blue-700">
                Direct (Ace)
              </button>
              <button onClick={() => confirmPointType('sideout')} className="bg-green-600 p-3 rounded font-bold text-sm hover:bg-green-700">
                Sideout
              </button>
              <button onClick={() => confirmPointType('block')} className="bg-purple-600 p-3 rounded font-bold text-sm hover:bg-purple-700">
                Blok
              </button>
              <button onClick={() => confirmPointType('attack')} className="bg-orange-600 p-3 rounded font-bold text-sm hover:bg-orange-700">
                Aanval
              </button>
              <button onClick={() => confirmPointType('error')} className="bg-red-600 p-3 rounded font-bold text-sm hover:bg-red-700 col-span-2">
                {showPointTypePopup.isServiceFault ? 'Service Fout' : 'Tegenstander Fout'}
              </button>
            </div>
            <button onClick={() => setShowPointTypePopup(null)} className="w-full mt-4 bg-gray-600 p-2 rounded text-sm hover:bg-gray-700">
              Annuleer
            </button>
          </div>
        </div>
      )}

      {showServiceFaultPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-md">
            <h3 className="text-xl font-bold mb-2 text-center text-red-400">⚠️ Service Fout</h3>
            <p className="text-sm text-gray-400 mb-1 text-center">
              Serveerder: <span className="text-white font-bold">#{showServiceFaultPopup.servingPlayer.number} {showServiceFaultPopup.servingPlayer.name}</span>
            </p>
            <p className="text-xs text-gray-500 mb-4 text-center">
              Punt gaat naar {showServiceFaultPopup.team === 'home' ? 'Ons Team' : 'Tegenstander'}
            </p>
            <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={() => confirmServiceFault('net')} 
                className="bg-blue-600 p-4 rounded font-bold text-sm hover:bg-blue-700 flex items-center justify-center gap-2"
              >
                <span className="text-2xl">🥅</span>
                <span>Bal in het Net</span>
              </button>
              <button 
                onClick={() => confirmServiceFault('out')} 
                className="bg-orange-600 p-4 rounded font-bold text-sm hover:bg-orange-700 flex items-center justify-center gap-2"
              >
                <span className="text-2xl">↗️</span>
                <span>Bal Uit</span>
              </button>
              <button 
                onClick={() => confirmServiceFault('footfault')} 
                className="bg-purple-600 p-4 rounded font-bold text-sm hover:bg-purple-700 flex items-center justify-center gap-2"
              >
                <span className="text-2xl">👟</span>
                <span>Voetfout</span>
              </button>
            </div>
            <button 
              onClick={() => setShowServiceFaultPopup(null)} 
              className="w-full mt-4 bg-gray-600 p-2 rounded text-sm hover:bg-gray-700"
            >
              Annuleer
            </button>
          </div>
        </div>
      )}

      {setEnded && !matchEnded && showLineupConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-40">
          <div className="bg-gray-800 p-6 rounded-lg max-w-sm text-center">
            <h2 className="text-2xl font-bold mb-3">{setWinner === 'home' ? '🎉 Set Gewonnen!' : '😢 Set Verloren'}</h2>
            <p className="text-lg mb-4">Stand: {sets.home} - {sets.away}</p>
            <p className="mb-4 text-sm">Opstelling behouden?</p>
            <div className="flex gap-3">
              <button onClick={() => startNewSet(true)} className="flex-1 bg-green-600 p-2 rounded font-bold text-sm">Ja</button>
              <button onClick={() => startNewSet(false)} className="flex-1 bg-blue-600 p-2 rounded font-bold text-sm">Nee</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 flex p-2 sm:p-4 overflow-hidden gap-2 sm:gap-4">
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex-1 flex items-center justify-center min-h-0 overflow-hidden">
            <div className="relative h-full w-auto max-w-full">
              <div className="relative h-full" style={{ aspectRatio: '9/18' }}>
                <div className="absolute top-0 left-0 right-0 h-1/2 bg-orange-400 border-4 border-white relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none select-none z-0" style={{ fontSize: '6rem', fontWeight: 'bold', color: 'white' }}>
                    {opponentName || 'Tegenstander'}
                  </div>
                  
                  <div className="absolute bottom-0 left-0 right-0 border-t-2 border-dashed border-white opacity-50" style={{ bottom: '33.33%' }} />
                  {renderAwayLineup()}
                  
                  {heatmapData.filter(d => d.team === 'home').map((p, i) => (
                    <div key={`current-home-${i}`} style={{ position: 'absolute', left: `${p.x}%`, top: `${p.y}%`, transform: 'translate(-50%, -50%)', width: '2rem', height: '2rem', backgroundColor: 'rgb(239, 68, 68)', opacity: 0.4, borderRadius: '50%', pointerEvents: 'none', zIndex: 10 }} />
                  ))}
                  
                  {showHeatmapOverlay !== null && savedHeatmaps[showHeatmapOverlay] && savedHeatmaps[showHeatmapOverlay].data.filter(d => d.team === 'home').map((p, i) => (
                    <div key={`overlay-home-${i}`} style={{ position: 'absolute', left: `${p.x}%`, top: `${p.y}%`, transform: 'translate(-50%, -50%)', width: '2.5rem', height: '2.5rem', backgroundColor: 'rgb(250, 204, 21)', opacity: 0.7, borderRadius: '50%', pointerEvents: 'none', zIndex: 15, border: '3px solid rgb(234, 179, 8)' }} />
                  ))}
                  
                  <div
                    className="absolute inset-0 cursor-pointer z-10"
                    onClick={(e) => {
                      if (substitutionMode || showPointTypePopup) return;
                      const rect = e.currentTarget.getBoundingClientRect();
                      const x = ((e.clientX - rect.left) / rect.width) * 100;
                      const y = ((e.clientY - rect.top) / rect.height) * 100;
                      scorePoint('home', x, y);
                    }}
                  />
                  <button onClick={(e) => { e.stopPropagation(); serviceFault('away'); }} className={`absolute top-1 right-1 px-1 sm:px-2 py-0.5 sm:py-1 rounded text-[10px] sm:text-xs font-bold z-30 pointer-events-auto ${servingTeam === 'away' ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-500 cursor-not-allowed opacity-50'}`}>
                    Service Fout
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); takeTimeout('away'); }} className="absolute top-1 left-1 bg-yellow-600 px-1 sm:px-2 py-0.5 sm:py-1 rounded text-[10px] sm:text-xs font-bold z-30 pointer-events-auto hover:bg-yellow-700">Timeout</button>
                </div>

                <div className="absolute top-1/2 left-0 right-0 h-2 bg-gray-900 transform -translate-y-1/2 z-10 border-t-2 border-b-2 border-yellow-400" />

                <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-orange-400 border-4 border-white relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none select-none z-0" style={{ fontSize: '6rem', fontWeight: 'bold', color: 'white' }}>
                    VCV
                  </div>
                  
                  <div className="absolute top-0 left-0 right-0 border-b-2 border-dashed border-white opacity-50" style={{ top: '33.33%' }} />
                  
                  {playSystem === '5-1' && showPenetration && !inServicePosition && (() => {
                    const setterInfo = getSetterInfo();
                    if (setterInfo && setterInfo.needsPenetration) {
                      const fromPos = getPositionStyle(setterInfo.position, false);
                      const toPos = { top: '25%', left: '50%' };
                      
                      return (
                        <svg className="absolute inset-0 pointer-events-none z-15" style={{ width: '100%', height: '100%' }}>
                          <defs>
                            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                              <polygon points="0 0, 10 3.5, 0 7" fill="#f59e0b" />
                            </marker>
                          </defs>
                          <line
                            x1={fromPos.left || fromPos.right || '50%'}
                            y1={fromPos.top || fromPos.bottom || '50%'}
                            x2={toPos.left}
                            y2={toPos.top}
                            stroke="#f59e0b"
                            strokeWidth="3"
                            strokeDasharray="5,5"
                            markerEnd="url(#arrowhead)"
                            opacity="0.8"
                          />
                        </svg>
                      );
                    }
                    return null;
                  })()}
                  
                  {renderHomeLineup()}
                  {heatmapData.filter(d => d.team === 'away').map((p, i) => (
                    <div key={`current-away-${i}`} style={{ position: 'absolute', left: `${p.x}%`, top: `${p.y}%`, transform: 'translate(-50%, -50%)', width: '2rem', height: '2rem', backgroundColor: 'rgb(59, 130, 246)', opacity: 0.4, borderRadius: '50%', pointerEvents: 'none', zIndex: 10 }} />
                  ))}
                  
                  {showHeatmapOverlay !== null && savedHeatmaps[showHeatmapOverlay] && savedHeatmaps[showHeatmapOverlay].data.filter(d => d.team === 'away').map((p, i) => (
                    <div key={`overlay-away-${i}`} style={{ position: 'absolute', left: `${p.x}%`, top: `${p.y}%`, transform: 'translate(-50%, -50%)', width: '2.5rem', height: '2.5rem', backgroundColor: 'rgb(250, 204, 21)', opacity: 0.7, borderRadius: '50%', pointerEvents: 'none', zIndex: 15, border: '3px solid rgb(234, 179, 8)' }} />
                  ))}
                  <div
                    className="absolute inset-0 cursor-pointer z-10"
                    onClick={(e) => {
                      if (substitutionMode || showPointTypePopup) return;
                      const rect = e.currentTarget.getBoundingClientRect();
                      const x = ((e.clientX - rect.left) / rect.width) * 100;
                      const y = ((e.clientY - rect.top) / rect.height) * 100;
                      scorePoint('away', x, y);
                    }}
                  />
                  <button onClick={(e) => { e.stopPropagation(); serviceFault('home'); }} className={`absolute bottom-1 right-1 px-1 sm:px-2 py-0.5 sm:py-1 rounded text-[10px] sm:text-xs font-bold z-30 pointer-events-auto ${servingTeam === 'home' ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-500 cursor-not-allowed opacity-50'}`}>
                    Service Fout
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); takeTimeout('home'); }} className="absolute bottom-1 left-1 bg-yellow-600 px-1 sm:px-2 py-0.5 sm:py-1 rounded text-[10px] sm:text-xs font-bold z-30 pointer-events-auto hover:bg-yellow-700">Timeout</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div 
          className={`bg-gray-800 rounded p-3 overflow-y-auto flex-shrink-0 relative z-30 ${isResizingCompact ? '' : 'transition-all duration-300'}`}
          style={{ 
            width: windowWidth < 640
              ? (sidebarExpanded ? `${Math.min(250, windowWidth * 0.35)}px` : `${compactSidebarWidth}px`)
              : windowWidth < 1024 
              ? (sidebarExpanded ? `${Math.min(320, windowWidth * 0.4)}px` : `${compactSidebarWidth}px`)
              : (sidebarExpanded ? '320px' : `${compactSidebarWidth}px`)
          }}
        >
          {/* Resize Handle voor compacte sidebar - LINKS */}
          <div 
            className="absolute left-0 top-0 bottom-0 w-2 sm:w-1 bg-gray-600 hover:bg-blue-500 cursor-col-resize z-50 group active:bg-blue-500"
            onMouseDown={() => setIsResizingCompact(true)}
            onTouchStart={() => setIsResizingCompact(true)}
          >
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-6 sm:w-4 h-16 sm:h-12 bg-gray-600 group-hover:bg-blue-500 group-active:bg-blue-500 rounded-r flex items-center justify-center">
              <div className="w-0.5 h-8 sm:h-6 bg-gray-400 mx-0.5"></div>
              <div className="w-0.5 h-8 sm:h-6 bg-gray-400 mx-0.5"></div>
            </div>
          </div>
          
          {!sidebarExpanded && (
            <div className="flex flex-col h-full">
              <div className="mb-4 pb-4 border-b border-gray-600">
                <div className="bg-gray-900 rounded p-2 mb-2">
                  <div className="flex items-center justify-center gap-1 sm:gap-2">
                    <div className="text-[10px] sm:text-xs text-gray-400 hidden sm:block">Stand:</div>
                    <div className="text-lg sm:text-2xl font-bold text-red-500">{homeScore}</div>
                    <div className="text-sm sm:text-xl font-bold text-gray-500">-</div>
                    <div className="text-lg sm:text-2xl font-bold text-blue-500">{awayScore}</div>
                  </div>
                </div>
                <div className="text-center text-[10px] sm:text-xs">
                  <div className="text-gray-400">Sets</div>
                  <div className="font-bold">{sets.home} - {sets.away}</div>
                </div>
                {(homeTimeouts.length > 0 || awayTimeouts.length > 0) && (
                  <div className="text-center text-[10px] sm:text-xs mt-2">
                    <div className="text-gray-400">TO</div>
                    <div className="text-[10px]">{homeTimeouts.length} - {awayTimeouts.length}</div>
                  </div>
                )}
              </div>

              <div className="mb-4">
                <h3 className="font-bold text-xs mb-2 text-center">Bank</h3>
                <div className="space-y-2">
                  {renderBenchArea().map((item, idx) => {
                    const roleLabel = getRoleLabel(item.player.role);
                    const isSelected = selectedBenchPlayer === item.player.id;
                    
                    return (
                      <div 
                        key={idx}
                        onClick={() => { 
                          if (item.reason === 'bench') {
                            setSidebarExpanded(true); 
                            setSubstitutionMode(true); 
                            setSelectedBenchPlayer(item.player.id); 
                          }
                        }}
                        className={`rounded-lg p-2 flex items-center gap-2 ${
                          item.reason === 'libero' || item.reason === 'libero-swap'
                            ? 'bg-slate-600 cursor-default border-2 border-slate-400' 
                            : isSelected
                            ? 'bg-yellow-600 cursor-pointer border-2 border-yellow-400'
                            : 'bg-gray-700 cursor-pointer hover:bg-gray-600'
                        }`}
                      >
                        <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-sm font-bold flex-shrink-0">
                          {item.player.number}
                        </div>
                        <div className="flex-1 text-left">
                          <div className="text-xs font-bold">{item.player.name}</div>
                          <div className="text-[10px] text-gray-300">{roleLabel}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex-1 border-t border-gray-600 pt-3 overflow-hidden flex flex-col">
                <h3 className="font-bold text-xs mb-2 text-center">Verloop</h3>
                <div className="flex-1 overflow-y-auto">
                  <table className="w-full text-[10px]">
                    <thead className="sticky top-0 bg-gray-800">
                      <tr className="border-b border-gray-600">
                        <th className="text-red-400 pb-1 text-left pl-1">Ons</th>
                        <th className="text-gray-500 pb-1">-</th>
                        <th className="text-blue-400 pb-1 text-right pr-1">Teg</th>
                        <th className="text-gray-400 pb-1 text-left pl-2">Type</th>
                      </tr>
                    </thead>
                    <tbody>
                      {scoreHistory.map((s, i) => {
                        const [homeS, awayS] = s.score.split('-').map(Number);
                        const typeLabels = {
                          'direct': '⚡ Ace',
                          'sideout': '🔄 Sideout', 
                          'block': '🛡️ Blok',
                          'attack': '⚔️ Aanval',
                          'error': '❌ Fout',
                          'servicefault': '⚠️ Service'
                        };
                        const typeLabel = typeLabels[s.type] || s.type;
                        const isHomePoint = s.team === 'home';
                        
                        return (
                          <tr key={i} className="border-b border-gray-700 hover:bg-gray-700">
                            <td className={`text-left py-1 font-bold pl-1 ${isHomePoint ? 'text-red-400' : 'text-gray-600'}`}>{homeS}</td>
                            <td className="text-center py-1 text-gray-500">-</td>
                            <td className={`text-right py-1 font-bold pr-1 ${!isHomePoint ? 'text-blue-400' : 'text-gray-600'}`}>{awayS}</td>
                            <td className="text-left py-1 text-gray-300 pl-2 text-[9px]">{typeLabel}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          
          {sidebarExpanded && (
            <div className="h-full flex flex-col">
              <div className="mb-4 pb-4 border-b border-gray-600">
                <div className="bg-gray-900 rounded p-3 mb-2">
                  <div className="flex justify-between items-center">
                    <div className="text-center flex-1">
                      <div className="text-xs text-gray-400 mb-1">Ons</div>
                      <div className="text-3xl font-bold text-red-500">{homeScore}</div>
                      <div className="text-xs text-gray-400 mt-1">Sets: {sets.home}</div>
                    </div>
                    <div className="text-2xl font-bold text-gray-500 px-3">-</div>
                    <div className="text-center flex-1">
                      <div className="text-xs text-gray-400 mb-1">Teg</div>
                      <div className="text-3xl font-bold text-blue-500">{awayScore}</div>
                      <div className="text-xs text-gray-400 mt-1">Sets: {sets.away}</div>
                    </div>
                  </div>
                </div>
                {(homeTimeouts.length > 0 || awayTimeouts.length > 0) && (
                  <div className="flex justify-between text-xs px-2">
                    <div>TO: {homeTimeouts.length}/2</div>
                    <div>TO: {awayTimeouts.length}/2</div>
                  </div>
                )}
              </div>

              <div className="flex-1 overflow-y-auto">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold text-sm">Wisselspelers</h3>
                  <button onClick={() => { setSidebarExpanded(false); setSubstitutionMode(false); setSelectedBenchPlayer(null); }} className="text-gray-400 hover:text-white">
                    <X size={20} />
                  </button>
                </div>
                
                {subError && <div className="bg-red-600 p-2 rounded mb-2 text-xs font-bold animate-pulse">⚠️ {subError}</div>}
                <p className="text-xs text-gray-400 mb-2">{6 - substitutions.length} wissels over</p>
                
                {benchPlayers.map(p => {
                  const roleLabel = getRoleLabel(p.role);
                  return (
                    <div 
                      key={p.id} 
                      onClick={() => { 
                        setSubstitutionMode(true); 
                        setSelectedBenchPlayer(p.id);
                      }}
                      className={`bg-gray-700 p-2 mb-2 rounded flex items-center justify-between text-sm cursor-pointer hover:bg-gray-600 ${selectedBenchPlayer === p.id ? 'ring-2 ring-green-400' : ''}`}
                    >
                      <span className="font-bold">#{p.number}</span>
                      <span className="text-xs">{p.name}</span>
                      <span className="text-xs text-gray-300 font-bold">{roleLabel}</span>
                    </div>
                  );
                })}
                
                {homeLineup.libero && (
                  <div className="mt-4 pt-4 border-t border-gray-600">
                    <p className="text-xs text-gray-400 mb-2">Libero (niet wisselbaar)</p>
                    <div className="bg-slate-600 p-2 rounded flex items-center justify-between text-sm opacity-70 cursor-not-allowed">
                      <span className="font-bold">#{players.find(p => p.id === homeLineup.libero)?.number}</span>
                      <span className="text-xs">{players.find(p => p.id === homeLineup.libero)?.name}</span>
                      <span className="text-xs text-slate-300">LIBERO</span>
                    </div>
                  </div>
                )}
                
                {substitutionMode && selectedBenchPlayer && (
                  <div className="bg-yellow-900 p-2 rounded mb-2 text-xs mt-4">
                    <p className="font-bold text-yellow-300">WISSEL ACTIEF</p>
                    <p className="text-yellow-200">Klik nu op veldspeler</p>
                    <button onClick={() => { setSubstitutionMode(false); setSelectedBenchPlayer(null); }} className="w-full bg-red-600 p-1 rounded mt-2 text-white">Annuleer</button>
                  </div>
                )}
                
                {substitutions.length > 0 && (
                  <div className="mt-3 mb-3 border-t border-gray-600 pt-3">
                    <h3 className="font-bold text-sm mb-2">Wissels</h3>
                    {substitutions.map((sub, i) => {
                      const outPlayer = players.find(p => p.id === sub.playerOut);
                      const inPlayer = players.find(p => p.id === sub.playerIn);
                      return (
                        <div key={i} className="bg-gray-700 p-2 mb-1 rounded text-xs">
                          <span className="text-red-400">#{outPlayer?.number}</span> → <span className="text-green-400">#{inPlayer?.number}</span>
                          <span className="text-gray-400 ml-2">({sub.score})</span>
                        </div>
                      );
                    })}
                  </div>
                )}
                
                <h3 className="font-bold text-sm mb-2 mt-4 border-t border-gray-600 pt-3">Score Verloop</h3>
                <div className="flex-1 overflow-y-auto border border-gray-700 rounded">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-gray-800">
                      <tr className="border-b-2 border-gray-600">
                        <th className="text-red-400 py-2 px-2">Ons</th>
                        <th className="text-gray-500 py-2">-</th>
                        <th className="text-blue-400 py-2 px-2">Teg</th>
                      </tr>
                    </thead>
                    <tbody>
                      {scoreHistory.map((s, i) => {
                        const [homeS, awayS] = s.score.split('-').map(Number);
                        return (
                          <tr key={i} className="border-b border-gray-700 hover:bg-gray-700">
                            <td className="text-center py-1 font-bold text-red-400">{homeS}</td>
                            <td className="text-center py-1 text-gray-500">-</td>
                            <td className="text-center py-1 font-bold text-blue-400">{awayS}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      {showConfirmSaveBeforeNew && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4">⚠️ Actieve Wedstrijd</h3>
            <p className="mb-6 text-center">Er is een actieve wedstrijd bezig. Wil je deze eerst opslaan?</p>
            
            <div className="bg-gray-700 p-3 rounded mb-4 text-sm">
              <p>Huidige stand: <strong>{sets.home} - {sets.away}</strong></p>
              <p>Score: <strong>{homeScore} - {awayScore}</strong></p>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={confirmStartNewWithSave} 
                className="flex-1 bg-green-600 p-3 rounded font-bold hover:bg-green-700"
              >
                💾 Ja, Opslaan
              </button>
              <button 
                onClick={confirmStartNewWithoutSave} 
                className="flex-1 bg-red-600 p-3 rounded font-bold hover:bg-red-700"
              >
                ❌ Niet Opslaan
              </button>
            </div>
            <button 
              onClick={() => setShowConfirmSaveBeforeNew(false)} 
              className="w-full mt-3 bg-gray-600 p-2 rounded hover:bg-gray-700"
            >
              Annuleer
            </button>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-sm mx-4">
            <h3 className="text-xl font-bold mb-4 text-center">🗑️ Wedstrijd Verwijderen</h3>
            <p className="mb-6 text-center">Weet je zeker dat je deze wedstrijd wilt verwijderen?</p>
            
            <div className="flex gap-3">
              <button 
                onClick={confirmDelete} 
                className="flex-1 bg-red-600 p-3 rounded font-bold hover:bg-red-700"
              >
                🗑️ Verwijderen
              </button>
              <button 
                onClick={() => setShowDeleteConfirm(null)} 
                className="flex-1 bg-gray-600 p-3 rounded hover:bg-gray-700"
              >
                Annuleer
              </button>
            </div>
          </div>
        </div>
      )}

      {showNewMatchDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4">Nieuwe Wedstrijd Starten</h3>
            
            <div className="mb-4">
              <label className="block text-sm mb-2">Tegenstander</label>
              <input 
                type="text" 
                value={opponentName} 
                onChange={(e) => setOpponentName(e.target.value)} 
                placeholder="Naam tegenstander" 
                className="w-full bg-gray-700 p-2 rounded text-white"
                autoFocus
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm mb-2">Datum</label>
              <input 
                type="date" 
                value={matchDate} 
                onChange={(e) => setMatchDate(e.target.value)} 
                className="w-full bg-gray-700 p-2 rounded text-white"
              />
            </div>

            <div className="flex gap-3">
              <button onClick={confirmNewMatch} className="flex-1 bg-green-600 p-3 rounded font-bold hover:bg-green-700">
                ▶️ Start Wedstrijd
              </button>
              <button onClick={() => setShowNewMatchDialog(false)} className="flex-1 bg-gray-600 p-3 rounded hover:bg-gray-700">
                Annuleer
              </button>
            </div>
          </div>
        </div>
      )}

      {showSaveDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4">
              {matchEnded ? (matchWinner === 'home' ? '🏆 Wedstrijd Gewonnen!' : '😢 Wedstrijd Verloren') : '💾 Wedstrijd Opslaan'}
            </h3>
            
            {!opponentName && (
              <div className="mb-4">
                <label className="block text-sm mb-2 text-yellow-400">⚠️ Tegenstander naam invullen</label>
                <input 
                  type="text" 
                  value={opponentName} 
                  onChange={(e) => setOpponentName(e.target.value)} 
                  placeholder="Naam tegenstander" 
                  className="w-full bg-gray-700 p-2 rounded text-white"
                  autoFocus
                />
              </div>
            )}
            
            <div className="bg-gray-700 p-4 rounded mb-4">
              <p className="text-lg mb-2">
                <strong>{opponentName || 'Tegenstander'}</strong>
              </p>
              <p className="text-sm text-gray-400 mb-3">{new Date(matchDate).toLocaleDateString('nl-NL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
              <p className="text-3xl font-bold mb-2">{sets.home} - {sets.away}</p>
              <p className="text-xs text-gray-400">Sets gespeeld: {savedHeatmaps.length}</p>
            </div>

            <p className="text-center mb-4 text-sm">Wil je deze wedstrijd opslaan?</p>

            <div className="flex gap-3">
              <button onClick={saveMatch} className="flex-1 bg-green-600 p-3 rounded font-bold hover:bg-green-700">
                💾 Opslaan
              </button>
              <button onClick={skipSave} className="flex-1 bg-gray-600 p-3 rounded hover:bg-gray-700">
                Niet Opslaan
              </button>
            </div>
          </div>
        </div>
      )}

      {showLoadDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 overflow-y-auto">
          <div className="bg-gray-800 p-6 rounded-lg max-w-2xl w-full mx-4 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">Wedstrijden Laden</h3>
              <button onClick={() => setShowLoadDialog(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>

            {savedMatches.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <p>Nog geen wedstrijden opgeslagen</p>
              </div>
            ) : (
              <div className="space-y-3">
                {savedMatches.slice().reverse().map((match) => (
                  <div key={match.id} className="bg-gray-700 p-4 rounded">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h4 className="font-bold text-lg">{match.opponent}</h4>
                        <p className="text-xs text-gray-400">{new Date(match.date).toLocaleDateString('nl-NL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold">
                          {match.finalScore.home} - {match.finalScore.away}
                        </div>
                        <div className="text-sm">
                          {match.winner === 'home' ? '🏆 Gewonnen' : '😢 Verloren'}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                      <div className="bg-gray-800 p-2 rounded">
                        <p className="text-gray-400">Sets Gespeeld</p>
                        <p className="font-bold">{match.savedHeatmaps?.length || 0}</p>
                      </div>
                      <div className="bg-gray-800 p-2 rounded">
                        <p className="text-gray-400">Wissels</p>
                        <p className="font-bold">{match.substitutions?.length || 0}</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button 
                        onClick={() => loadMatch(match)} 
                        className="flex-1 bg-blue-600 p-2 rounded text-sm font-bold hover:bg-blue-700"
                      >
                        📂 Laden
                      </button>
                      <button 
                        onClick={() => deleteMatch(match.id)} 
                        className="bg-red-600 px-4 p-2 rounded text-sm font-bold hover:bg-red-700"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {matchEnded && !showSaveDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-40">
          <div className="bg-gray-800 p-6 rounded-lg max-w-sm text-center">
            <h2 className="text-3xl font-bold mb-3">{matchWinner === 'home' ? '🏆 GEWONNEN!' : '😢 VERLOREN'}</h2>
            <p className="text-xl mb-4">{sets.home} - {sets.away}</p>
            <button onClick={() => setShowNewMatchDialog(true)} className="bg-green-600 px-6 py-2 rounded font-bold hover:bg-green-700">Nieuwe Wedstrijd</button>
          </div>
        </div>
      )}

    </div>
  );
}
